# This file makes the 'api' directory a Python package.
# You can also define a base Blueprint here if you have common API functionalities,
# or import and register all your API blueprints if you prefer that organization.

# For now, it can remain empty or be used to gather all blueprint registrations.
