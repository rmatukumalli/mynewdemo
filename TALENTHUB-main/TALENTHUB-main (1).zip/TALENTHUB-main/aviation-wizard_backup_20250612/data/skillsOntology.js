export const capabilitiesData = [];

export const competenciesData = [];

export const skillsData = [];
