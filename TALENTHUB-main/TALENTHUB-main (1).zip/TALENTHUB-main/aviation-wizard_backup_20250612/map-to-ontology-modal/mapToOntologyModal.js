// aviation-wizard/map-to-ontology-modal/mapToOntologyModal.js (Simplified for debugging)

export function openMapToOntologyModal(jobId, aiSkillDetails) {
    console.log('[Debug] openMapToOntologyModal called with:', jobId, aiSkillDetails);
    alert('Simplified mapToOntologyModal.js loaded. Functionality disabled for debugging.');
}

console.log('Simplified Map to Ontology Modal module loaded for debugging.');
