const careerPathsModule = {
    init: function() {
        // No initialization needed as the content is self-contained.
    }
};

window.careerPathsModule = careerPathsModule;
