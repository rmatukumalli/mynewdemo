export function init(appData, openModal, closeModal, updateWizardState, getFormHTML, callAPI, contentWrapper) {
    // No custom JavaScript needed for this step with hardcoded data
}
