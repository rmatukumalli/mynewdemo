// JavaScript for ATS Dashboard
document.addEventListener('DOMContentLoaded', () => {
    // console.log("ATS Dashboard JS Loaded");
    // Add any specific JS for the ATS dashboard page here
});
