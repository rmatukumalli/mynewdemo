// Scripts for Project Timeline page
document.addEventListener('DOMContentLoaded', function() {
    console.log('Project Timeline JS loaded');
});
