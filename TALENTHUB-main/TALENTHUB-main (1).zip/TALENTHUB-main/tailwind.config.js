/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './job-architecture/**/*.html',
    './job-architecture/**/*.js',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
